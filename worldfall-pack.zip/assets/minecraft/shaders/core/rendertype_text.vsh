#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

void main() {
    vec3 placed = Position;
    // WorldFall: the pickup list is written at the top of the screen in colours of its own, and is put at the left edge here.
    ivec3 tint = ivec3(round(Color.rgb * 255.0));
    bool onScreen = ProjMat[3][3] == 1.0 && ProjMat[2][3] == 0.0;
    if (onScreen && Color.a > 0.99 && Position.y >= 0.0 && Position.y < 1600.0
            && (tint.r & 7) == 5 && (tint.g & 7) == 2 && (tint.b & 7) == 6) {
        float screenWidth = 2.0 / abs(ProjMat[0][0]);
        float screenHeight = 2.0 / abs(ProjMat[1][1]);
        // How far down it was written says three things: which line of the list (the hundreds), which boss bar
        // it is the name of (the nineteens, thrown away, so other bars coming and going do not move the list),
        // and where in the letter this corner is (what is left).
        float listLine = floor((Position.y + 0.01) / 200.0);
        float inLine = Position.y - listLine * 200.0;
        float inLetter = inLine - floor((inLine + 0.01) / 19.0) * 19.0;
        placed.x += 8.0 - screenWidth / 2.0;
        placed.y = screenHeight / 2.0 - 30.0 + listLine * 10.0 + inLetter - 3.0;
    }
    gl_Position = ProjMat * ModelViewMat * vec4(placed, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = UV0;
}
