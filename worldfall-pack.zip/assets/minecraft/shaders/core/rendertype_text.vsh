#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

void main() {
    vec3 placed = Position;
    // WorldFall: the pickup list is written at the top of the screen in colours of its own, and is put at the left edge here.
    ivec3 tint = ivec3(round(Color.rgb * 255.0));
    bool onScreen = ProjMat[3][3] == 1.0 && ProjMat[2][3] == 0.0;
    if (onScreen && Color.a > 0.99 && Position.y < 260.0
            && (tint.r & 7) == 5 && (tint.g & 7) == 2 && (tint.b & 7) == 6) {
        float screenWidth = 2.0 / abs(ProjMat[0][0]);
        float screenHeight = 2.0 / abs(ProjMat[1][1]);
        placed.x += 8.0 - screenWidth / 2.0;
        placed.y += screenHeight / 2.0 - 33.0;
    }
    gl_Position = ProjMat * ModelViewMat * vec4(placed, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = Color * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = UV0;
}
